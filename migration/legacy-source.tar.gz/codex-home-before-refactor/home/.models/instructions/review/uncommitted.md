Review the current code changes (staged, unstaged, and untracked files) and provide prioritized findings.
